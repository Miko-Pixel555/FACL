# Course Tracker

Full student course-completion tracker with a real shared database: public certificate submissions, admin-only review, and a leaderboard that only counts approved courses. Built with Next.js (App Router), Tailwind CSS, Recharts, Lucide icons, and **Supabase** (Postgres + Auth + Storage + Row Level Security).

## How the review rule is enforced

This isn't just app logic — it's enforced by the database itself, so it can't be bypassed even by someone calling the API directly:

1. A **trigger** forces every new submission's status to `pending` on insert, no matter what the request contains.
2. A **Row Level Security policy** only allows `UPDATE` (approve/reject) on the `submissions` table for an **authenticated** (logged-in admin) session — anonymous requests are rejected by Postgres itself.
3. The leaderboard and stats only ever count rows where `status = 'approved'`.

So a submission genuinely cannot count toward anything until an admin reviews and approves it.

## Setup (about 10 minutes)

### 1. Create a Supabase project
Go to https://supabase.com → New project (the free tier is enough). Wait ~2 minutes for it to spin up.

### 2. Run the schema
In your Supabase project: **SQL Editor → New query** → paste the entire contents of `supabase/schema.sql` from this repo → **Run**.

This creates all tables, the review-enforcement trigger, RLS policies, a public `certificates` storage bucket, and some starter data (universities, faculties, categories, courses).

### 3. Create your admin login
**Authentication → Users → Add user** → enter an email + password. This is what you'll use to log into the Admin/Dashboard/Review area in the app — there's no separate "admin123"-style password anymore.

### 4. Get your API keys
**Project Settings → API** → copy the **Project URL** and the **anon public** key.

### 5. Set environment variables
Copy `.env.example` to `.env.local` and fill in the two values from step 4:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key
```

### 6. Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000, submit a test course, then log in with your admin account to review it.

## Deploy to Vercel

1. Push this repo to GitHub.
2. https://vercel.com/new → import the repo.
3. Before deploying, add the same two environment variables from step 5 in **Vercel → Project Settings → Environment Variables**.
4. Deploy.

## What's real now vs. still a demo simplification

Real: shared Postgres database (all users see the same data), admin authentication via Supabase Auth, RLS-enforced review workflow, actual certificate files stored in Supabase Storage, live updates (new/approved submissions refresh automatically for everyone via Supabase Realtime).

Still simplified vs. the original spec, if you want to go further:
- Anyone can currently *read* submissions (needed since students have no accounts to scope access to) — if you want submission data fully private except to admins, that requires adding light student accounts or one-time access tokens.
- No pagination yet on large tables — fine for hundreds–low thousands of rows, worth adding (`.range()` queries) if you expect much more.
- No Excel/CSV export yet — straightforward to add with a library like `xlsx` reading from the `submissions` query.

Claude Code is a good next step if you want help adding any of those.
